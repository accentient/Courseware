Add-PSSnapin Microsoft.SharePoint.PowerShell
New-SPUser -useralias "vsalm\tfs administrators" �displayname "TFS Administrators" �web "http://vsalm" �PermissionLevel "Full Control"
New-SPUser -useralias "vsalm\scrum team" �displayname "Scrum Team" �web "http://vsalm" �PermissionLevel "Full Control"
New-SPUser -useralias "vsalm\stakeholders" �displayname "Stakeholders" �web "http://vsalm" �PermissionLevel "Read"
